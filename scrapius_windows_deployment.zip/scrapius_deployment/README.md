# 🤖 **Scrapius Facebook Bot - Ready for Windows Deployment**

## Quick Start:
1. Install Python 3.11+ from python.org
2. Run `setup_windows.bat`
3. Edit `.env` file with your API keys
4. Run `python main.py`

For detailed instructions, see `WINDOWS_INSTALLATION_GUIDE.md`
